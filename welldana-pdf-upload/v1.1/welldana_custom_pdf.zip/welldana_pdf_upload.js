jQuery(document).ready(function($) {
    var file_frame;

    $('#welldana_upload_pdf_button').on('click', function(event) {
        event.preventDefault();

        // If the media frame already exists, reopen it.
        if (file_frame) {
            file_frame.open();
            return;
        }

        // Create the media frame.
        file_frame = wp.media.frames.file_frame = wp.media({
            title: pdf_uploader_data.title, // Use localized string
			button: {
				text: pdf_uploader_data.button, // Use localized string
			},
            multiple: false,  // Only allow one file to be selected
            library: {
                type: 'application/pdf' // Only show PDFs in the library
            }
        });

        // When a file is selected, run a callback.
        file_frame.on('select', function() {
            // We set multiple to false so only get one file from the uploader
            var attachment = file_frame.state().get('selection').first().toJSON();

            // Do something with attachment.id and/or attachment.url, for example:
            $('#pdf_attachment_id').val(attachment.id);
            $('#pdf_preview').html('<a href="' + attachment.url + '" target="_blank">' + attachment.filename + '</a>'); // Basic preview
        });

        // Finally, open the modal
        file_frame.open();
    });
});