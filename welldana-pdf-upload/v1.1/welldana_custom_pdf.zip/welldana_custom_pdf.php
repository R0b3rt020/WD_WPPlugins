<?php
/*
Plugin Name: Welldana Produkt PDF
Plugin URI: https://welldana.dk
Description: This plugin will make a PDF to single product in WooCommerce for custom websites
Version: 1.1
Author: Welldana
Author URI: https://welldana.dk
*/

// Automatic Update Functionality
function welldana_check_for_plugin_update($transient) {
    if (empty($transient->checked)) {
        return $transient;
    }

    $plugin_slug = 'welldana-produkt-pdf/'; // Adjust to match your plugin's folder structure
    $current_version = get_file_data(__FILE__, ['Version' => 'Version'])['Version'];

    $response = wp_remote_get('https://github.com/R0b3rt020/WD_WPPlugins/blob/main/welldana-pdf-upload/v1.1/welldana_pdf_upload.zip');
    if (is_wp_error($response)) {
        return $transient;
    }

    $updates = json_decode(wp_remote_retrieve_body($response), true);

    if (isset($updates['welldana-produkt-pdf']) && version_compare($current_version, $updates['welldana-produkt-pdf']['version'], '<')) {
        $transient->response[$plugin_slug] = (object) [
            'slug'        => 'welldana-produkt-pdf',
            'new_version' => $updates['welldana-produkt-pdf']['version'],
            'package'     => $updates['welldana-produkt-pdf']['download_url'],
            'tested'      => '6.0', // Adjust as needed
        ];
    }

    return $transient;
}
add_filter('site_transient_update_plugins', 'welldana_check_for_plugin_update');

// Force Auto-Updates
add_filter('auto_update_plugin', function($update, $item) {
    return ($item->slug === 'welldana-produkt-pdf') ? true : $update;
}, 10, 2);



if ( ! function_exists( 'welldana_woo_custom_product_tabs' ) ) {
    add_filter( 'woocommerce_product_tabs', 'welldana_woo_custom_product_tabs' );
    function welldana_woo_custom_product_tabs( $tabs ) {

		// 1) Removing tabs
		// unset( $tabs['description'] );              // Remove the description tab
		// unset( $tabs['reviews'] );               // Remove the reviews tab
		// unset( $tabs['additional_information'] );   // Remove the additional information tab

        // 2) Adding new tabs
        $tabs['attrib_desc_tab'] = array(
            'title'     => __( 'Dokument', 'woocommerce' ),
            'priority'  => 100,
            'callback'  => 'welldana_woo_attrib_desc_tab_content'
        );

        return $tabs;
    }
}

if ( ! function_exists( 'welldana_woo_attrib_desc_tab_content' ) ) {
    // New Tab contents
    function welldana_woo_attrib_desc_tab_content() {
        $product_id = get_the_ID();
        $args = array(
            'post_type'      => 'attachment',
            'numberposts'    => -1,
            'post_status'    => null,
            'post_parent'    => $product_id,
            'post_mime_type' => 'application/pdf', // Filter by PDF mime type
        );
        $attachments = get_posts( $args );

        if ( $attachments ) {
            echo '<ul>';
            foreach ( $attachments as $attachment ) {
                echo '<li style="padding:5px;">';
                echo '<img src="' . plugin_dir_url(__FILE__) . '/images/pdf.png" alt="" />';  //Make sure you have a pdf.png in the images folder
                echo '<a href="' . wp_get_attachment_url( $attachment->ID ) . '" target="_blank"><span style="font-size:16px;">' . basename( wp_get_attachment_url( $attachment->ID ) ) . '</span></a>';
                echo '</li>';
            }
            echo '</ul>';
        } else {
            echo 'No PDF available';
        }
    }
}

if ( ! function_exists( 'welldana_add_pdf_upload_metabox' ) ) {
    // Add a placeholder for PDF uploads in the product edit page
    add_action( 'add_meta_boxes', 'welldana_add_pdf_upload_metabox' );
    function welldana_add_pdf_upload_metabox() {
        add_meta_box(
            'pdf_upload_metabox',
            __( 'Upload PDF', 'woocommerce' ),
            'welldana_pdf_upload_metabox_callback',
            'product',
            'side'
        );
    }
}

if ( ! function_exists( 'welldana_pdf_upload_metabox_callback' ) ) {
    function welldana_pdf_upload_metabox_callback( $post ) {
        // Add a nonce field.  This is important for security.
        wp_nonce_field( 'pdf_upload_nonce_action', 'pdf_upload_nonce' );

        // Display existing PDFs
        $args = array(
            'post_type'      => 'attachment',
            'numberposts'    => -1,
            'post_status'    => null,
            'post_parent'    => $post->ID,
            'post_mime_type' => 'application/pdf' // Filter by PDF mime type
        );
        $attachments = get_posts( $args );

        if ( $attachments ) {
            echo '<ul>';
            foreach ( $attachments as $attachment ) {
                echo '<li>';
                echo '<a href="' . wp_get_attachment_url( $attachment->ID ) . '" target="_blank">' . basename( wp_get_attachment_url( $attachment->ID ) ) . '</a>';
                echo ' <input type="checkbox" name="delete_pdfs[]" value="' . $attachment->ID . '"> ' . __( 'Delete', 'woocommerce' );
                echo '</li>';
            }
            echo '</ul>';
        } else {
            echo 'No PDF available';
        }

        // Upload new PDF
        echo '<input type="hidden" id="pdf_attachment_id" name="pdf_attachment_id" value="" />';
        echo '<br><button type="button" class="button" id="welldana_upload_pdf_button">' . __( 'Upload PDF', 'woocommerce' ) . '</button>';
        echo '<div id="pdf_preview"></div>';
    }
}

if ( ! function_exists( 'welldana_load_wp_media_files' ) ) {
    // Enqueue media scripts
    add_action( 'admin_enqueue_scripts', 'welldana_load_wp_media_files' );
    function welldana_load_wp_media_files( $hook ) {
        // Only load the script on the product edit page.  This is important for performance.
        if ( 'post.php' != $hook && 'post-new.php' != $hook ) {
            return;
        }
        global $post_type;
        if ( 'product' != $post_type ) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_script( 'pdf-upload-script', plugin_dir_url(__FILE__) . 'welldana_pdf_upload.js', array('jquery'), '1.0', true ); // Add version number for cache busting

        // Localize the script with new data
        $translation_array = array(
            'title'  => __( 'Select or Upload a PDF', 'woocommerce' ),
            'button' => __( 'Use this PDF', 'woocommerce' ),
        );
        wp_localize_script( 'pdf-upload-script', 'pdf_uploader_data', $translation_array );
    }
}

if ( ! function_exists( 'welldana_save_pdf_upload' ) ) {
    // Save the uploaded PDF and delete existing PDFs if checked
    add_action( 'save_post', 'welldana_save_pdf_upload' );
    function welldana_save_pdf_upload( $post_id ) {

        // Check if our nonce is set and verify it.
        if ( ! isset( $_POST['pdf_upload_nonce'] ) || ! wp_verify_nonce( $_POST['pdf_upload_nonce'], 'pdf_upload_nonce_action' ) ) {
            return;
        }

        // If this is an autosave, our form has not been submitted, so we don't want to do anything.
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // Check the user's permissions.
        if ( isset( $_POST['post_type'] ) && 'product' == $_POST['post_type'] ) {
            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return;
            }
        } else {
            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                return;
            }
        }

        // Delete selected PDFs
        if ( isset( $_POST['delete_pdfs'] ) && is_array( $_POST['delete_pdfs'] ) ) {
            foreach ( $_POST['delete_pdfs'] as $pdf_id ) {
                wp_delete_attachment( $pdf_id, true ); // true for permanently deleting
            }
        }

        // Save new PDF attachment ID
        if ( isset( $_POST['pdf_attachment_id'] ) && !empty( $_POST['pdf_attachment_id'] ) ) {
            $attachment_id = intval( $_POST['pdf_attachment_id'] );
            // Sanitize and validate the attachment ID.  Always a good idea.
            if ( get_post_type( $attachment_id ) == 'attachment' ) {
                wp_update_post( array(
                    'ID'          => $attachment_id,
                    'post_parent' => $post_id
                ) );
            }
        }
    }
}